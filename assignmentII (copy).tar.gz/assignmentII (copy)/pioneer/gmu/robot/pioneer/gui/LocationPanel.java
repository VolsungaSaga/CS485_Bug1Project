/*
 * LocationPanel.java
 *
 * Created on October 19, 2006, 8:34 PM
 * By Sean Robinette
 */

package gmu.robot.pioneer.gui;

import java.awt.*;
import javax.swing.*;

public class LocationPanel extends JPanel {
    double vLeft;
    double vRight;
    double vc;
    
    public LocationPanel() {
        }
    
    }
